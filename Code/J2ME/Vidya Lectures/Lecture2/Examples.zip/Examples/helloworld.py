import appuifw
appuifw.note(u"Hello", 'info')
